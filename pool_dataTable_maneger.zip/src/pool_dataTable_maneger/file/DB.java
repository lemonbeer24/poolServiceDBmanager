package pool_dataTable_maneger.file;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DB {
	
	public static Connection conn;
	public static Statement stmt;
	public static String location;
	
	public static void init() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");//드라이버 설치
			
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE",//thin:로컬호스트:포트번호:db이름
					"pool_maneger","1234");//드라이버 메니져 연결후 객체 생성
			
			stmt = conn.createStatement();//문장을 만들어 쿼리를 보낼수 있는 객체 생성
			System.out.println("DB 연결 성공.");
			location = "창구";
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "jdbc 드라이버 로드 오류!","",JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "DB 연결 오류!","",JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	
	public static ResultSet getResultSet(String sql) {
		try {
			Statement stmt = conn.createStatement();
			return stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static int Update(String sql) {
		try {
			
			int var =stmt.executeUpdate(sql);
			
			for (int i = 0; i < Maneger_view.list_jpTable.size(); i++) {//refresh
				Maneger_view.list_jpTable.elementAt(i).refresh();
			}
			
			return var;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
}
